
# Register for SAP Discovery Center

1. Open in your browser: https://discovery-center.cloud.sap/

![](./images/0_Register_for_DC1.png)

2. Allow Cookies here

![](./images/0_Register_for_DC2.png)

3. Logon / Complete the registration for SAP Discovery Center

![](./images/0_Register_for_DC3.png)
 
 
