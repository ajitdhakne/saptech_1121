Navigate to the SAP Discovery Center and start the exercises from there: 
https://discovery-center.cloud.sap/missiondetail/4105/
